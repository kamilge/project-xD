import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.GridLayout;


public class App implements ActionListener
{  
    public static void losuj(){
        int[] wylosowane =new int[8];
        int wylosowanych = 0;
        do
        {
            int liczba = wylosuj();
            if( czyBylaWylosowana( liczba, wylosowane, wylosowanych ) == false )
            {
                wylosowane[ wylosowanych ] = liczba;
                wylosowanych++;
            } 
        } while( wylosowanych < 8 );
        wylosowanych = 0;
    do
    {
       System.out.println(wylosowane[wylosowanych]);
        wylosowanych++;
    } while( wylosowanych < 8 );
        



        
}
public static int wylosuj(){
return (int)(Math.random() *24);
}
public static Boolean czyBylaWylosowana( int iLiczba, int tab[], int ile ){
    if( ile <= 0 )
    return false;
int i = 0;
do
{
       if( tab[ i ] == iLiczba )
        return true; 
   i++;
} while( i < ile );
return false;
}


    public static void main(String[] args) {
     
        int iloscStatkow=8;

        JFrame frame = new JFrame();
        frame.setTitle("Batleship game");
        frame.setSize(1215,441);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        frame.getContentPane().setBackground(new Color(0xadd8e6)); 
        frame.setLayout(null);
        frame.setResizable(false);
        
        JPanel twoJPanel2 = new JPanel();
        twoJPanel2.setLayout(new GridLayout(5,5,4,4));; 
        twoJPanel2.setBounds(700,0,500,400);
        twoJPanel2.setBackground(Color.lightGray);

        JButton[] wlabel = new JButton[25];
        for( int y=0; y<25;y++){ 
         
            wlabel[y] = new JButton();
            wlabel[y].setText("label" + y);
            wlabel[y].setSize(50, 30);
            wlabel[y].setFocusable(false);
            wlabel[y].setEnabled(false);
            twoJPanel2.add(wlabel[y]);
        }
        
        JPanel twoJPanel = new JPanel();
        twoJPanel.setLayout(new GridLayout(5,5,4,4));
        twoJPanel.setSize(500,400); 
        twoJPanel.setBounds(0,0,500,400);
        twoJPanel.setBackground(Color.magenta);


 JButton[] label = new JButton[25];
        for( int x=0; x<25;x++){ 
         
            label[x] = new JButton();
            label[x].setText("label" + x);
            label[x].setSize(50, 30);
            label[x].setFocusable(false); 
           label[1].addActionListener(e -> {
            iloscStatkow=-1;
           });
            twoJPanel.add(label[x]);
        }
        
        
JLabel xd = new JLabel("Rozloz swoje statki");
xd.setBounds(550,50,120,40);

JLabel statki=new JLabel("Pozoztale statki:"+iloscStatkow);
statki.setBounds(550,90,120,40);

       JButton losuj = new JButton();
       losuj.setBounds(540,250,120,40);
       losuj.setText("zacznij gre");
       losuj.addActionListener(e -> {
           losuj();
           for(int y=0;y<25;y++){
           wlabel[y].setEnabled(true);
           label[y].setEnabled(false);
           }
        }); 
        if(iloscStatkow!=0){
            losuj.setEnabled(false);
        } 
            
        frame.add(statki);
        frame.add(xd); 
        frame.add(losuj);
        frame.add(twoJPanel);
        frame.add(twoJPanel2);
        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        
    }



}



  

